
CREATE TABLE IF NOT EXISTS players (
  id SERIAL PRIMARY KEY,
  name VARCHAR(255) NOT NULL,
  date_of_birth DATE,
  position VARCHAR(50),
  primary_club VARCHAR(255),
  market_value_eur INTEGER,
  minutes_last_12m INTEGER,
  goals_last_12m INTEGER,
  assists_last_12m INTEGER,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);
