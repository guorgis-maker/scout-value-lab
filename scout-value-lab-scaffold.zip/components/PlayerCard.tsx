
import React from 'react'

export default function PlayerCard() {
  return (
    <div className="bg-white p-4 rounded-lg shadow">
      <h3 className="font-semibold">John Doe</h3>
      <p className="text-sm text-gray-600">Age: 22 · CM · FC Example</p>
      <div className="mt-3 text-lg font-bold">€1.2M</div>
      <div className="mt-2 text-sm text-gray-500">Goals 5 · Assists 7 · 1800 min</div>
    </div>
  )
}
