
import React, { useState } from 'react'

export default function SearchBar() {
  const [q, setQ] = useState('')
  return (
    <div className="mb-4">
      <input
        value={q}
        onChange={(e) => setQ(e.target.value)}
        placeholder="Search players, clubs..."
        className="w-full p-3 rounded border"
      />
    </div>
  )
}
