
import Head from 'next/head'
import PlayerCard from '../components/PlayerCard'
import SearchBar from '../components/SearchBar'

export default function Home() {
  return (
    <div className="min-h-screen bg-gray-50">
      <Head>
        <title>Scout Value Lab</title>
      </Head>
      <main className="max-w-4xl mx-auto p-6">
        <h1 className="text-3xl font-bold mb-4">Scout Value Lab — MVP</h1>
        <SearchBar />
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-6">
          {/* Example static player cards for now */}
          <PlayerCard />
          <PlayerCard />
        </div>
      </main>
    </div>
  )
}
