
import type { NextApiRequest, NextApiResponse } from 'next'

const players = [
  {
    id: 1,
    name: 'John Doe',
    age: 22,
    position: 'CM',
    club: 'FC Example',
    market_value_eur: 1200000,
    minutes_last_12m: 1800,
    goals: 5,
    assists: 7
  },
  {
    id: 2,
    name: 'Alex Striker',
    age: 25,
    position: 'ST',
    club: 'United Sample',
    market_value_eur: 3500000,
    minutes_last_12m: 2100,
    goals: 18,
    assists: 4
  }
]

export default function handler(req: NextApiRequest, res: NextApiResponse) {
  res.status(200).json(players)
}
